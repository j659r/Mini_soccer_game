
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let player = { x: 100, y: 200, size: 30, color: "blue" };
let ball = { x: 200, y: 250, radius: 10, dx: 2, dy: 2 };

document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowUp") player.y -= 5;
  if (e.key === "ArrowDown") player.y += 5;
  if (e.key === "ArrowLeft") player.x -= 5;
  if (e.key === "ArrowRight") player.x += 5;
});

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = player.color;
  ctx.fillRect(player.x, player.y, player.size, player.size);

  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
  ctx.fillStyle = "white";
  ctx.fill();
  ctx.closePath();

  ball.x += ball.dx;
  ball.y += ball.dy;

  if (ball.x <= 0 || ball.x >= canvas.width) ball.dx *= -1;
  if (ball.y <= 0 || ball.y >= canvas.height) ball.dy *= -1;

  requestAnimationFrame(draw);
}

draw();
